
from telegram.ext import Application, CommandHandler, MessageHandler, filters
import requests
import re

# توكن البوت
TOKEN = '7700823862:AAFMxD7B1iAc0Nw6IJRIGibVArfMaD7mK6g'

# دالة لمعرفة نوع الإدخال
def detect_input_type(text):
    if re.match(r'^\+?\d{6,15}$', text):
        return 'phone'
    elif '@' in text and '.' in text:
        return 'email'
    elif text.isdigit():
        return 'id'
    else:
        return 'username'

# البحث في HaveIBeenPwned عن الإيميلات
def search_hibp(email):
    url = f"https://haveibeenpwned.com/unifiedsearch/{email}"
    headers = {
        "User-Agent": "Mozilla/5.0",
        "hibp-api-key": "لا يحتاج مفتاح حالياً للبحث العادي"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return True
    elif response.status_code == 404:
        return False
    else:
        return None

# البحث في Numlookup عن الأرقام
def search_numlookup(number):
    url = f"https://www.numlookup.com/number/{number}"
    response = requests.get(url)
    if "not found" in response.text.lower() or "غير موجود" in response.text.lower():
        return False
    elif response.status_code == 200:
        return True
    else:
        return None

# الوظيفة الأساسية عند استقبال رسالة
async def handle_message(update, context):
    user_input = update.message.text.strip()
    input_type = detect_input_type(user_input)
    
    if input_type == 'email' or input_type == 'username':
        await update.message.reply_text(f"جاري البحث عن {user_input} في التسريبات...")
        result = search_hibp(user_input)
        if result is True:
            await update.message.reply_text("تم العثور على تسريبات لهذا الإيميل أو اليوزر!")
        elif result is False:
            await update.message.reply_text("لم يتم العثور على تسريبات.")
        else:
            await update.message.reply_text("حدث خطأ أثناء البحث، حاول لاحقاً.")

    elif input_type == 'phone':
        await update.message.reply_text(f"جاري البحث عن الرقم {user_input}...")
        result = search_numlookup(user_input)
        if result is True:
            await update.message.reply_text("تم العثور على معلومات مرتبطة بهذا الرقم!")
        elif result is False:
            await update.message.reply_text("لم يتم العثور على معلومات لهذا الرقم.")
        else:
            await update.message.reply_text("حدث خطأ أثناء البحث عن الرقم.")

    elif input_type == 'id':
        await update.message.reply_text("تم استلام ID، حالياً لا يتم البحث بالـID مباشرة. (قريباً بإذن الله).")
    else:
        await update.message.reply_text("لم أستطع تحديد نوع الإدخال. تأكد من صحته.")

# الوظيفة الأساسية للتشغيل
def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()

if __name__ == '__main__':
    main()
