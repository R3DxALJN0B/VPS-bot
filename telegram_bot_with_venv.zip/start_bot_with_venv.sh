
#!/bin/bash
# تحديث النظام
sudo apt update

# تثبيت Python3 و pip3 و virtualenv
sudo apt install -y python3 python3-pip python3-venv

# إنشاء بيئة افتراضية
python3 -m venv botenv

# تفعيل البيئة الافتراضية
source botenv/bin/activate

# تثبيت المكتبات داخل البيئة الافتراضية
pip install --upgrade pip
pip install -r requirements.txt

# تشغيل البوت
python3 bot.py
