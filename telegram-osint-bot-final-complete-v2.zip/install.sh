
#!/bin/bash

echo "تثبيت المتطلبات العامة..."
sudo apt update
sudo apt install -y python3 python3-pip git curl

echo "تثبيت مكتبات بايثون..."
pip3 install -r requirements.txt

echo "تحميل الأدوات..."

# Sherlock
if [ ! -d "sherlock" ]; then
  git clone https://github.com/sherlock-project/sherlock.git
fi

# PhoneInfoga
if [ ! -d "phoneinfoga" ]; then
  git clone https://github.com/sundowndev/phoneinfoga.git
  cd phoneinfoga && pip3 install -r requirements.txt && cd ..
fi

# theHarvester
if [ ! -d "theHarvester" ]; then
  git clone https://github.com/laramies/theHarvester.git
  cd theHarvester && pip3 install -r requirements/base.txt && cd ..
fi

# Holehe
if [ ! -d "holehe" ]; then
  git clone https://github.com/megadose/holehe.git
  cd holehe && pip3 install -r requirements.txt && cd ..
fi

# Socialscan
if [ ! -d "socialscan" ]; then
  git clone https://github.com/iojw/socialscan.git
  cd socialscan && pip3 install -r requirements.txt && cd ..
fi

echo "تم التثبيت بنجاح. لتشغيل البوت:"
echo "python3 bot.py"
